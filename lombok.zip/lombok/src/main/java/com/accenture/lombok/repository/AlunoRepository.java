package com.accenture.lombok.repository;

import com.accenture.lombok.model.Aluno;
import org.springframework.data.repository.CrudRepository;

public interface AlunoRepository  extends CrudRepository<Aluno, Integer>{

}
