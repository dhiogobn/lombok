package com.accenture.lombok;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LombokApplicationTests {

	@Test
	void contextLoads() {
	}

}
